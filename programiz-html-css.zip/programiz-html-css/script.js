document.addEventListener('DOMContentLoaded', function() {
    const elements = {
        'H': '1s1',
        'He': '1s2',
        'Li': '1s2 2s1',
        'Be': '1s2 2s2',
        'B': '1s2 2s2 2p1',
        // Tambah lebih banyak unsur di sini
    };

    const periodicTable = document.getElementById('periodic-table');
    const elementName = document.getElementById('element-name');
    const elementConfig = document.getElementById('element-config');

    // Buat elemen untuk setiap unsur
    for (const [symbol, config] of Object.entries(elements)) {
        const elementDiv = document.createElement('div');
        elementDiv.className = 'element';
        elementDiv.textContent = symbol;
        elementDiv.addEventListener('click', function() {
            elementName.textContent = symbol;
            elementConfig.textContent = config;
        });
        periodicTable.appendChild(elementDiv);
    }
});
